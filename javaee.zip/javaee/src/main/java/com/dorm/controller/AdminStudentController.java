package com.dorm.controller;

import com.dorm.entity.DormRoom;
import com.dorm.entity.Student;
import com.dorm.service.DormRoomService;
import com.dorm.service.StudentService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/admin/student")
public class AdminStudentController {

    @Resource
    private StudentService studentService;
    @Resource
    private DormRoomService dormRoomService;

    @GetMapping("/list")
    public String list(@RequestParam(value = "stuNo", required = false) String stuNo,
                       @RequestParam(value = "name", required = false) String name,
                       @RequestParam(value = "college", required = false) String college,
                       Model model) {
        Map<String, Object> params = new HashMap<>();
        params.put("stuNo", stuNo);
        params.put("name", name);
        params.put("college", college);
        List<Student> list = studentService.search(params);
        model.addAttribute("list", list);
        model.addAttribute("stuNo", stuNo);
        model.addAttribute("name", name);
        model.addAttribute("college", college);
        return "admin/admin-student-list";
    }

    @GetMapping("/add")
    public String addPage(Model model) {
        model.addAttribute("student", new Student());
        return "admin/admin-student-form";
    }

    @PostMapping("/save")
    public String save(Student student) {
        if (student.getId() == null) {
            studentService.add(student);
        } else {
            studentService.update(student);
        }
        return "redirect:/admin/student/list";
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, Model model) {
        Student student = studentService.getById(id);
        model.addAttribute("student", student);
        return "admin/admin-student-form";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable("id") Integer id) {
        studentService.delete(id);
        return "redirect:/admin/student/list";
    }

    // 宿舍分配页面
    @GetMapping("/assign/{id}")
    public String assignPage(@PathVariable("id") Integer id, Model model) {
        Student student = studentService.getById(id);
        List<DormRoom> dormList = dormRoomService.findAvailableDorms();
        model.addAttribute("student", student);
        model.addAttribute("dormList", dormList);
        return "admin/admin-dorm-assign";
    }

    // 宿舍分配提交
    @PostMapping("/assign")
    public String assign(@RequestParam("id") Integer id,
                         @RequestParam("dormId") Integer dormId,
                         @RequestParam("bedNo") Integer bedNo) {
        Student s = studentService.getById(id);
        Integer oldDormId = s.getDormId();
        s.setDormId(dormId);
        s.setBedNo(bedNo);
        studentService.update(s);

        // 更新宿舍占用人数
        if (oldDormId != null) {
            dormRoomService.getById(oldDormId); // 可用来判断存在
        }
        return "redirect:/admin/student/list";
    }
}
