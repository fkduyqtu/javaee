package com.dorm.entity;

public class DormRoom {
    private Integer id;
    private Integer buildingId;
    private String roomNo;
    private Integer bedCount;
    private Integer occupiedCount;
    private String status;

    // 关联宿舍楼
    private Building building;

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public Integer getBuildingId() { return buildingId; }
    public void setBuildingId(Integer buildingId) { this.buildingId = buildingId; }

    public String getRoomNo() { return roomNo; }
    public void setRoomNo(String roomNo) { this.roomNo = roomNo; }

    public Integer getBedCount() { return bedCount; }
    public void setBedCount(Integer bedCount) { this.bedCount = bedCount; }

    public Integer getOccupiedCount() { return occupiedCount; }
    public void setOccupiedCount(Integer occupiedCount) { this.occupiedCount = occupiedCount; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Building getBuilding() { return building; }
    public void setBuilding(Building building) { this.building = building; }
}
