package com.dorm.service;

import com.dorm.entity.DormRoom;

import java.util.List;

public interface DormRoomService {
    List<DormRoom> findAllWithBuilding();
    DormRoom getById(Integer id);
    int saveOrUpdate(DormRoom dormRoom);
    int delete(Integer id);
    List<DormRoom> findAvailableDorms();
}
