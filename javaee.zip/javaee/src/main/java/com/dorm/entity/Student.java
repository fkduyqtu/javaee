package com.dorm.entity;

public class Student {
    private Integer id;
    private String stuNo;
    private String password;
    private String name;
    private String gender;
    private String college;
    private String clazz;
    private String phone;
    private Integer dormId;
    private Integer bedNo;

    // 关联映射：学生 -> 宿舍房间
    private DormRoom dormRoom;

    // getter & setter
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getStuNo() { return stuNo; }
    public void setStuNo(String stuNo) { this.stuNo = stuNo; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getCollege() { return college; }
    public void setCollege(String college) { this.college = college; }

    public String getClazz() { return clazz; }
    public void setClazz(String clazz) { this.clazz = clazz; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public Integer getDormId() { return dormId; }
    public void setDormId(Integer dormId) { this.dormId = dormId; }

    public Integer getBedNo() { return bedNo; }
    public void setBedNo(Integer bedNo) { this.bedNo = bedNo; }

    public DormRoom getDormRoom() { return dormRoom; }
    public void setDormRoom(DormRoom dormRoom) { this.dormRoom = dormRoom; }
}
