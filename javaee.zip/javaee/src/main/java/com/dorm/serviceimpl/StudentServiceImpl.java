package com.dorm.serviceimpl;

import com.dorm.entity.Student;
import com.dorm.mapper.StudentMapper;
import com.dorm.service.StudentService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {

    @Resource
    private StudentMapper studentMapper;

    @Override
    public Student login(String stuNo, String password) {
        Student s = studentMapper.findByStuNo(stuNo);
        if (s != null && s.getPassword().equals(password)) {
            return s;
        }
        return null;
    }

    @Override
    public Student getById(Integer id) {
        return studentMapper.findById(id);
    }

    @Override
    public Student getWithDormByStuNo(String stuNo) {
        return studentMapper.findWithDormByStuNo(stuNo);
    }

    @Override
    public List<Student> search(Map<String, Object> params) {
        return studentMapper.searchStudents(params);
    }

    @Override
    public int add(Student student) {
        return studentMapper.insertStudent(student);
    }

    @Override
    public int update(Student student) {
        return studentMapper.updateStudent(student);
    }

    @Override
    public int delete(Integer id) {
        return studentMapper.deleteById(id);
    }

    @Override
    public int updatePassword(Integer id, String newPassword) {
        Student s = new Student();
        s.setId(id);
        s.setPassword(newPassword);
        return studentMapper.updateStudent(s);
    }
}
