package com.dorm.mapper;

import com.dorm.entity.DormRoom;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface DormRoomMapper {
    List<DormRoom> findAllWithBuilding();

    DormRoom findById(@Param("id") Integer id);

    int insert(DormRoom dormRoom);

    int update(DormRoom dormRoom);

    int delete(@Param("id") Integer id);

    // 查询空余床位的宿舍
    List<DormRoom> findAvailableDorms();

    int increaseOccupied(@Param("id") Integer id);

    int decreaseOccupied(@Param("id") Integer id);
}
