package com.dorm.service;

import com.dorm.entity.Student;

import java.util.List;
import java.util.Map;

public interface StudentService {

    Student login(String stuNo, String password);

    Student getById(Integer id);

    Student getWithDormByStuNo(String stuNo);

    List<Student> search(Map<String, Object> params);

    int add(Student student);

    int update(Student student);

    int delete(Integer id);

    int updatePassword(Integer id, String newPassword);
}
