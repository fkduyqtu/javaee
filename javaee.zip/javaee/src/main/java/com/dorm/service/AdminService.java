package com.dorm.service;

import com.dorm.entity.Admin;

public interface AdminService {
    Admin login(String username, String password);

    int updateProfile(Admin admin);

    void update(Admin admin);

    Object getById(Integer id);
}
