package com.dorm.serviceimpl;

import com.dorm.entity.Building;
import com.dorm.mapper.BuildingMapper;
import com.dorm.service.BuildingService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

@Service
@Transactional
public class BuildingServiceImpl implements BuildingService {

    @Resource
    private BuildingMapper buildingMapper;

    @Override
    public List<Building> findAll() {
        return buildingMapper.findAll();
    }

    @Override
    public Building getById(Integer id) {
        return buildingMapper.findById(id);
    }

    @Override
    public int saveOrUpdate(Building building) {
        if (building.getId() == null) {
            return buildingMapper.insert(building);
        }
        return buildingMapper.update(building);
    }

    @Override
    public int delete(Integer id) {
        return buildingMapper.delete(id);
    }
}
