package com.dorm.mapper;

import com.dorm.entity.Admin;
import org.apache.ibatis.annotations.Param;

public interface AdminMapper {
    Admin findByUsername(@Param("username") String username);
    int updateAdmin(Admin admin);

    Admin getById(Integer id);
}
