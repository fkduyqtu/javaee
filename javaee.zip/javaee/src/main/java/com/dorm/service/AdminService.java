package com.dorm.service;

import com.dorm.entity.Admin;

public interface AdminService {
    Admin login(String username, String password);

    int updateProfile(Admin admin);

    int update(Admin admin);

    Admin getById(Integer id);
}
