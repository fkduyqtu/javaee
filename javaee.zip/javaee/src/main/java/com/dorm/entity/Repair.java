package com.dorm.entity;

import java.util.Date;

public class Repair {
    private Integer id;
    private Integer studentId;
    private Integer dormId;
    private String type;
    private String description;
    private String status;
    private Date createTime;
    private Date updateTime;
    private Integer handlerId;

    // 关联学生 & 宿舍 & 管理员
    private Student student;
    private DormRoom dormRoom;
    private Admin handler;

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public Integer getStudentId() { return studentId; }
    public void setStudentId(Integer studentId) { this.studentId = studentId; }

    public Integer getDormId() { return dormId; }
    public void setDormId(Integer dormId) { this.dormId = dormId; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Date getCreateTime() { return createTime; }
    public void setCreateTime(Date createTime) { this.createTime = createTime; }

    public Date getUpdateTime() { return updateTime; }
    public void setUpdateTime(Date updateTime) { this.updateTime = updateTime; }

    public Integer getHandlerId() { return handlerId; }
    public void setHandlerId(Integer handlerId) { this.handlerId = handlerId; }

    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }

    public DormRoom getDormRoom() { return dormRoom; }
    public void setDormRoom(DormRoom dormRoom) { this.dormRoom = dormRoom; }

    public Admin getHandler() { return handler; }
    public void setHandler(Admin handler) { this.handler = handler; }
}
