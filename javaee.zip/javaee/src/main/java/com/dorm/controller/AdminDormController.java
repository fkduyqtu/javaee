package com.dorm.controller;

import com.dorm.entity.Building;
import com.dorm.entity.DormRoom;
import com.dorm.service.BuildingService;
import com.dorm.service.DormRoomService;
import com.dorm.service.RepairService;
import com.dorm.service.StudentService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminDormController {

    @Resource
    private BuildingService buildingService;
    @Resource
    private DormRoomService dormRoomService;
    @Resource
    private StudentService studentService;
    @Resource
    private RepairService repairService;

    // 仪表盘首页
    @GetMapping("/main")
    public String main(Model model) {
        int studentCount = studentService.search(null).size();
        int dormCount = dormRoomService.findAllWithBuilding().size();
        int repairing = (int) repairService.getAllForAdmin().stream()
                .filter(r -> !"已完成".equals(r.getStatus())).count();

        model.addAttribute("studentCount", studentCount);
        model.addAttribute("dormCount", dormCount);
        model.addAttribute("repairing", repairing);
        return "admin/admin-main";
    }

    // 宿舍楼列表
    @GetMapping("/building/list")
    public String buildingList(Model model) {
        List<Building> list = buildingService.findAll();
        model.addAttribute("list", list);
        return "admin/admin-building-list";
    }

    @GetMapping("/building/add")
    public String buildingAdd(Model model) {
        model.addAttribute("building", new Building());
        return "admin/admin-building-form";
    }

    @GetMapping("/building/edit/{id}")
    public String buildingEdit(@PathVariable("id") Integer id, Model model) {
        Building b = buildingService.getById(id);
        model.addAttribute("building", b);
        return "admin/admin-building-form";
    }

    @PostMapping("/building/save")
    public String buildingSave(Building building) {
        buildingService.saveOrUpdate(building);
        return "redirect:/admin/building/list";
    }

    @GetMapping("/building/delete/{id}")
    public String buildingDelete(@PathVariable("id") Integer id) {
        buildingService.delete(id);
        return "redirect:/admin/building/list";
    }

    // 宿舍房间管理
    @GetMapping("/dorm/list")
    public String dormList(Model model) {
        List<DormRoom> list = dormRoomService.findAllWithBuilding();
        model.addAttribute("list", list);
        return "admin/admin-dorm-list";
    }

    @GetMapping("/dorm/add")
    public String dormAdd(Model model) {
        model.addAttribute("dorm", new DormRoom());
        model.addAttribute("buildings", buildingService.findAll());
        return "admin/admin-dorm-form";
    }

    @GetMapping("/dorm/edit/{id}")
    public String dormEdit(@PathVariable("id") Integer id, Model model) {
        DormRoom d = dormRoomService.getById(id);
        model.addAttribute("dorm", d);
        model.addAttribute("buildings", buildingService.findAll());
        return "admin/admin-dorm-form";
    }

    @PostMapping("/dorm/save")
    public String dormSave(DormRoom dorm) {
        dormRoomService.saveOrUpdate(dorm);
        return "redirect:/admin/dorm/list";
    }

    @GetMapping("/dorm/delete/{id}")
    public String dormDelete(@PathVariable("id") Integer id) {
        dormRoomService.delete(id);
        return "redirect:/admin/dorm/list";
    }
}
