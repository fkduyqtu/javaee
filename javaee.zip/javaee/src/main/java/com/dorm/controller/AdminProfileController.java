package com.dorm.controller;

import com.dorm.entity.Admin;
import com.dorm.service.AdminService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin")
public class AdminProfileController {

    @Resource
    private AdminService adminService;

    // 显示管理员个人资料页
    @GetMapping("/profile")
    public String profile(HttpSession session, Model model) {
        Admin admin = (Admin) session.getAttribute("admin");
        if (admin == null) return "redirect:/login";

        model.addAttribute("admin", admin);
        return "admin/admin-profile";
    }

    // 保存管理员资料
    @PostMapping("/profile/save")
    public String save(Admin admin, HttpSession session) {
        adminService.update(admin);   // 你已有 update 方法
        session.setAttribute("admin", adminService.getById(admin.getId()));
        return "redirect:/admin/profile";
    }

    // 修改密码界面
    @GetMapping("/password")
    public String passwordPage() {
        return "admin/admin-password";
    }

    // 保存密码
    @PostMapping("/password")
    public String changePassword(HttpSession session,
                                 @RequestParam String oldPwd,
                                 @RequestParam String newPwd,
                                 Model model) {

        Admin admin = (Admin) session.getAttribute("admin");
        if (admin == null) return "redirect:/login";

        if (!admin.getPassword().equals(oldPwd)) {
            model.addAttribute("msg", "原密码错误！");
            return "admin/admin-password";
        }

        admin.setPassword(newPwd);
        adminService.update(admin);
        return "redirect:/admin/main";
    }
}
