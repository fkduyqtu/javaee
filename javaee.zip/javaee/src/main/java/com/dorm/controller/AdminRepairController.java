package com.dorm.controller;

import com.dorm.entity.Admin;
import com.dorm.entity.Repair;
import com.dorm.service.RepairService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/admin/repair")
public class AdminRepairController {

    @Resource
    private RepairService repairService;

    @GetMapping("/list")
    public String list(Model model) {
        List<Repair> list = repairService.getAllForAdmin();
        model.addAttribute("list", list);
        return "admin/admin-repair-list";
    }

    @GetMapping("/updateStatus")
    public String updateStatus(@RequestParam("id") Integer id,
                               @RequestParam("status") String status,
                               HttpSession session) {
        Admin admin = (Admin) session.getAttribute("admin");
        if (admin != null) {
            repairService.updateStatus(id, status, admin.getId());
        }
        return "redirect:/admin/repair/list";
    }
}
