package com.dorm.serviceimpl;

import com.dorm.entity.Repair;
import com.dorm.mapper.RepairMapper;
import com.dorm.service.RepairService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

@Service
@Transactional
public class RepairServiceImpl implements RepairService {

    @Resource
    private RepairMapper repairMapper;

    @Override
    public int addRepair(Repair repair) {
        repair.setStatus("待处理");
        return repairMapper.insert(repair);
    }

    @Override
    public List<Repair> getByStudentId(Integer studentId) {
        return repairMapper.findByStudentId(studentId);
    }

    @Override
    public List<Repair> getAllForAdmin() {
        return repairMapper.findAllWithStudentDorm();
    }

    @Override
    public int updateStatus(Integer id, String status, Integer handlerId) {
        return repairMapper.updateStatus(id, status, handlerId);
    }
}
