package com.dorm.serviceimpl;

import com.dorm.entity.Admin;
import com.dorm.mapper.AdminMapper;
import com.dorm.service.AdminService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class AdminServiceImpl implements AdminService {

    @Resource
    private AdminMapper adminMapper;

    @Override
    public Admin login(String username, String password) {
        Admin admin = adminMapper.findByUsername(username);
        if (admin != null && admin.getPassword().equals(password)) {
            return admin;
        }
        return null;
    }

    @Override
    public int updateProfile(Admin admin) {
        return adminMapper.updateAdmin(admin);
    }

    @Override
    public Admin getById(Integer id) {
        return adminMapper.getById(id);
    }

    @Override
    public int update(Admin admin) {
        return adminMapper.updateAdmin(admin);
    }

}
