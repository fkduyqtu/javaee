package com.dorm.entity;

public class Building {
    private Integer id;
    private String code;
    private String name;
    private Integer floors;
    private String remark;

    // getter & setter
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Integer getFloors() { return floors; }
    public void setFloors(Integer floors) { this.floors = floors; }

    public String getRemark() { return remark; }
    public void setRemark(String remark) { this.remark = remark; }
}
