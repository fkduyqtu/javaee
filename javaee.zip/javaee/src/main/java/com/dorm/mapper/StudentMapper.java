package com.dorm.mapper;

import com.dorm.entity.Student;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface StudentMapper {
    Student findByStuNo(@Param("stuNo") String stuNo);

    Student findById(@Param("id") Integer id);

    // 动态条件 + 模糊查询
    List<Student> searchStudents(Map<String, Object> params);

    int insertStudent(Student student);

    int updateStudent(Student student);

    int deleteById(@Param("id") Integer id);

    // 关联查询：学生 + 宿舍
    Student findWithDormByStuNo(@Param("stuNo") String stuNo);
}
