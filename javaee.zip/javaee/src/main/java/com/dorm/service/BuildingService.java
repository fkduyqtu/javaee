package com.dorm.service;

import com.dorm.entity.Building;

import java.util.List;

public interface BuildingService {
    List<Building> findAll();
    Building getById(Integer id);
    int saveOrUpdate(Building building);
    int delete(Integer id);
}
