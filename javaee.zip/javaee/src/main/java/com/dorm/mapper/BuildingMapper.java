package com.dorm.mapper;

import com.dorm.entity.Building;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface BuildingMapper {
    List<Building> findAll();
    Building findById(@Param("id") Integer id);
    int insert(Building building);
    int update(Building building);
    int delete(@Param("id") Integer id);
}
