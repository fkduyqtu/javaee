package com.dorm.service;

import com.dorm.entity.Repair;

import java.util.List;

public interface RepairService {
    int addRepair(Repair repair);
    List<Repair> getByStudentId(Integer studentId);
    List<Repair> getAllForAdmin();
    int updateStatus(Integer id, String status, Integer handlerId);
}
