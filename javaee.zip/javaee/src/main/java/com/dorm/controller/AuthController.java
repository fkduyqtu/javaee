package com.dorm.controller;

import com.dorm.entity.Admin;
import com.dorm.entity.Student;
import com.dorm.service.AdminService;
import com.dorm.service.StudentService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

@Controller
public class AuthController {

    @Resource
    private AdminService adminService;
    @Resource
    private StudentService studentService;

    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String doLogin(@RequestParam("username") String username,
                          @RequestParam("password") String password,
                          @RequestParam("role") String role,
                          HttpSession session,
                          Model model) {

        if ("ADMIN".equals(role)) {
            Admin admin = adminService.login(username, password);
            if (admin == null) {
                model.addAttribute("msg", "管理员账号或密码错误");
                return "login";
            }
            session.setAttribute("admin", admin);
            return "redirect:/admin/main";
        } else {
            Student student = studentService.login(username, password);
            if (student == null) {
                model.addAttribute("msg", "学号或密码错误");
                return "login";
            }
            session.setAttribute("student", student);
            return "redirect:/student/main";
        }
    }

    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }

    @PostMapping("/register")
    public String doRegister(Student student, Model model) {
        // 简单注册：stuNo + password + name 必须有
        if (student.getStuNo() == null || student.getStuNo().trim().isEmpty()) {
            model.addAttribute("msg", "学号不能为空");
            return "register";
        }
        if (student.getPassword() == null || student.getPassword().trim().isEmpty()) {
            model.addAttribute("msg", "密码不能为空");
            return "register";
        }
        if (student.getName() == null || student.getName().trim().isEmpty()) {
            model.addAttribute("msg", "姓名不能为空");
            return "register";
        }
        studentService.add(student);
        model.addAttribute("msg", "注册成功，请登录");
        return "login";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}
