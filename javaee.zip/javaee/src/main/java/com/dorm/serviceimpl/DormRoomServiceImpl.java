package com.dorm.serviceimpl;

import com.dorm.entity.DormRoom;
import com.dorm.mapper.DormRoomMapper;
import com.dorm.service.DormRoomService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

@Service
@Transactional
public class DormRoomServiceImpl implements DormRoomService {

    @Resource
    private DormRoomMapper dormRoomMapper;

    @Override
    public List<DormRoom> findAllWithBuilding() {
        return dormRoomMapper.findAllWithBuilding();
    }

    @Override
    public DormRoom getById(Integer id) {
        return dormRoomMapper.findById(id);
    }

    @Override
    public int saveOrUpdate(DormRoom dormRoom) {
        if (dormRoom.getId() == null) {
            return dormRoomMapper.insert(dormRoom);
        }
        return dormRoomMapper.update(dormRoom);
    }

    @Override
    public int delete(Integer id) {
        return dormRoomMapper.delete(id);
    }

    @Override
    public List<DormRoom> findAvailableDorms() {
        return dormRoomMapper.findAvailableDorms();
    }
}
