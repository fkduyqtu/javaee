package com.dorm.controller;

import com.dorm.entity.Repair;
import com.dorm.entity.Student;
import com.dorm.service.DormRoomService;
import com.dorm.service.RepairService;
import com.dorm.service.StudentService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/student")
public class StudentController {

    @Resource
    private StudentService studentService;
    @Resource
    private DormRoomService dormRoomService;
    @Resource
    private RepairService repairService;

    @GetMapping("/main")
    public String main() {
        return "student/student-main";
    }

    // 个人信息
    @GetMapping("/profile")
    public String profile(HttpSession session, Model model) {
        Student s = (Student) session.getAttribute("student");
        Student detail = studentService.getById(s.getId());
        model.addAttribute("student", detail);
        return "student/student-profile";
    }

    @PostMapping("/profile/save")
    public String saveProfile(Student student, HttpSession session) {
        Student s = (Student) session.getAttribute("student");
        student.setId(s.getId());
        studentService.update(student);
        return "redirect:/student/profile";
    }

    // 修改密码
    @GetMapping("/password")
    public String passwordPage() {
        return "student/student-password";
    }

    @PostMapping("/password")
    public String changePassword(@RequestParam("oldPassword") String oldPassword,
                                 @RequestParam("newPassword") String newPassword,
                                 HttpSession session,
                                 Model model) {
        Student s = (Student) session.getAttribute("student");
        Student db = studentService.getById(s.getId());
        if (!db.getPassword().equals(oldPassword)) {
            model.addAttribute("msg", "原密码错误");
            return "student/student-password";
        }
        studentService.updatePassword(s.getId(), newPassword);
        model.addAttribute("msg", "密码修改成功");
        return "student/student-password";
    }

    // 我的宿舍
    @GetMapping("/dorm")
    public String myDorm(HttpSession session, Model model) {
        Student s = (Student) session.getAttribute("student");
        Student withDorm = studentService.getWithDormByStuNo(s.getStuNo());
        model.addAttribute("student", withDorm);
        return "student/student-dorm";
    }

    // 报修相关
    @GetMapping("/repair/list")
    public String repairList(HttpSession session, Model model) {
        Student s = (Student) session.getAttribute("student");
        List<Repair> list = repairService.getByStudentId(s.getId());
        model.addAttribute("list", list);
        return "student/student-repair-list";
    }

    @GetMapping("/repair/add")
    public String repairAdd() {
        return "student/student-repair-form";
    }

    @PostMapping("/repair/save")
    public String repairSave(@RequestParam("type") String type,
                             @RequestParam("description") String description,
                             HttpSession session) {
        Student s = (Student) session.getAttribute("student");
        Student full = studentService.getById(s.getId());
        Repair repair = new Repair();
        repair.setStudentId(full.getId());
        repair.setDormId(full.getDormId());
        repair.setType(type);
        repair.setDescription(description);
        repairService.addRepair(repair);
        return "redirect:/student/repair/list";
    }
}
