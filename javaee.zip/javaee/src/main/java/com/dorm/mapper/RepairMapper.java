package com.dorm.mapper;

import com.dorm.entity.Repair;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface RepairMapper {
    int insert(Repair repair);

    // 学生端：查自己的报修
    List<Repair> findByStudentId(@Param("studentId") Integer studentId);

    // 管理员端：所有报修 + 关联学生和宿舍
    List<Repair> findAllWithStudentDorm();

    int updateStatus(@Param("id") Integer id,
                     @Param("status") String status,
                     @Param("handlerId") Integer handlerId);
}
